#ifndef CONNECT_H
#define CONNECT_H

int analyzer(int array_in[], int size);//function prototype

#endif
