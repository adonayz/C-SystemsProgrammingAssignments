/** mystring.h
 * @author Mike Ciaraldi
 * My own versions of some of the C-style string functions
*/

char* mystrdup(const char* src);
